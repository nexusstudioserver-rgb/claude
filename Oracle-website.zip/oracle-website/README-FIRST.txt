================================================================
 ORACLE DECOMPILER  -  put this on your domain in 30 seconds
================================================================

What happened: only index.html got uploaded. The site also
needs the small server file that does the decompiling, and
without it every upload fails (that is the 404 you saw).

HOW TO FIX IT

  1. Unzip this folder somewhere (Desktop is fine).
  2. Go to  https://vercel.com/new
  3. Drag the whole unzipped folder onto the page.
     - Framework preset: Other
     - Everything else: leave empty
  4. Press Deploy.

That is it. The site will then decompile by itself - whole
Roblox games up to about 48 MB, and single .luac files.

THE FOLDER MUST LOOK EXACTLY LIKE THIS
(the api folder has to come along - it is the server)

    oracle-website/
      index.html            the page you already uploaded
      api/
        decompile.py        <-- THE SERVER. without this, nothing works
      vercel.json
      requirements.txt
      favicon.ico
      icon.png
      apple-touch-icon.png
      DEPLOY.md             the long version of this note

If the api/ folder is missing or flat (decompile.py sitting
next to index.html instead of inside api/), the page will show
a red bar at the top saying "This website is missing its
server part" - that is your signal to check the layout.

TO CHECK IT WORKED

  Open  https://your-domain/api/decompile
  You should see:  {"ok": true, "service": "Oracle decompiler endpoint", ...}

  If you get "The page could not be found", the server file
  did not make it into the deployment - redo step 3 and make
  sure you drag the whole folder, not just index.html.
